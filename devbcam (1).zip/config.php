<?php

$token = "MxJ_IM"; // Token
$dev = "1371365451"; // Admin id
define('API_KEY', $token);